const foundElement = document.querySelector("p")

console.log(foundElement.childNodes);
console.log(foundElement.firstChild);
console.log(foundElement.lastChild);
console.log(foundElement.previousSibling);
console.log(foundElement.nextSibling);
console.log(foundElement.parentNode);
console.log(foundElement.parentElement);
console.log(foundElement.children);
console.log(foundElement.firstElementChild);
console.log(foundElement.lastElementChild);
console.log(foundElement.previousElementSibling);
console.log(foundElement.nextElementSibling);
